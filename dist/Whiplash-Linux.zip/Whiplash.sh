#!/bin/sh
java  -jar Whiplash.jar
        